use axum::{
    extract::Query,
    http::StatusCode,
    response::{Html, IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::{Path, PathBuf};
use std::time::UNIX_EPOCH;

use crate::compress::compress_to_archive;
use crate::decompress::decompress_archive;
use crate::utils::{
    dirs_path, get_disk_info, home_dir_str, read_mal_info, resolve, time_from_secs, DiskInfo,
};
use crate::verify::verify_archive;

#[derive(Deserialize)]
struct ListQuery {
    path: String,
}

#[derive(Serialize)]
struct EntryJson {
    name: String,
    full_path: String,
    kind: String,
    size: Option<u64>,
    original_size: Option<u64>,
    ratio: Option<f64>,
    modified: Option<String>,
}

#[derive(Serialize)]
struct ListResponse {
    current_path: String,
    entries: Vec<EntryJson>,
    disk: Option<DiskInfo>,
}

async fn handle_list(Query(q): Query<ListQuery>) -> Response {
    let base = resolve(&q.path);

    if !base.exists() || !base.is_dir() {
        return (StatusCode::BAD_REQUEST, format!("Chemin invalide: {:?}", base)).into_response();
    }

    match fs::read_dir(&base) {
        Err(e) => (StatusCode::BAD_REQUEST, e.to_string()).into_response(),
        Ok(rd) => {
            let mut entries: Vec<EntryJson> = Vec::new();
            for item in rd.flatten() {
                let name = item.file_name().to_string_lossy().to_string();
                let full_path = item.path().to_string_lossy().to_string();
                let meta = match item.metadata() {
                    Ok(m) => m,
                    Err(_) => continue,
                };
                let modified = meta
                    .modified()
                    .ok()
                    .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
                    .map(|d| {
                        let dt = time_from_secs(d.as_secs());
                        format!("{:04}-{:02}-{:02} {:02}:{:02}", dt.0, dt.1, dt.2, dt.3, dt.4)
                    });

                if meta.is_dir() {
                    entries.push(EntryJson {
                        name,
                        full_path,
                        kind: "dir".into(),
                        size: None,
                        original_size: None,
                        ratio: None,
                        modified,
                    });
                } else {
                    let size = meta.len();
                    let path = item.path();
                    let is_mal = name.ends_with(".mal");
                    if is_mal {
                        let info = read_mal_info(&path);
                        entries.push(EntryJson {
                            name,
                            full_path,
                            kind: "mal".into(),
                            size: Some(size),
                            original_size: info.as_ref().map(|i| i.original_size),
                            ratio: info.as_ref().map(|i| i.ratio),
                            modified,
                        });
                    } else {
                        entries.push(EntryJson {
                            name,
                            full_path,
                            kind: "file".into(),
                            size: Some(size),
                            original_size: None,
                            ratio: None,
                            modified,
                        });
                    }
                }
            }
            entries.sort_by(|a, b| {
                let ad = a.kind == "dir";
                let bd = b.kind == "dir";
                if ad && !bd {
                    return std::cmp::Ordering::Less;
                }
                if !ad && bd {
                    return std::cmp::Ordering::Greater;
                }
                a.name.to_lowercase().cmp(&b.name.to_lowercase())
            });

            let disk = get_disk_info(&base);
            let current_path = base.to_string_lossy().to_string();
            Json(ListResponse {
                current_path,
                entries,
                disk,
            })
            .into_response()
        }
    }
}

#[derive(Deserialize)]
struct FavQuery {
    key: String,
}

#[derive(Serialize)]
struct FavResponse {
    path: String,
}

async fn handle_favpath(Query(q): Query<FavQuery>) -> Response {
    let path = match q.key.as_str() {
        "home" => home_dir_str(),
        "desktop" => dirs_path("Desktop"),
        "documents" => dirs_path("Documents"),
        "downloads" => dirs_path("Downloads"),
        _ => home_dir_str(),
    };
    Json(FavResponse { path }).into_response()
}

#[derive(Deserialize)]
struct CompressReq {
    full_paths: Vec<String>,
    output_dir: String,
    output_name: String,
    level: u8,
}

#[derive(Serialize)]
struct CompressResp {
    saved_pct: f64,
    original: u64,
    compressed: u64,
    output_path: String,
}

async fn handle_compress(Json(req): Json<CompressReq>) -> Response {
    let inputs: Vec<PathBuf> = req.full_paths.iter().map(|p| PathBuf::from(p)).collect();

    for p in &inputs {
        if !p.exists() {
            return (StatusCode::BAD_REQUEST, format!("Introuvable: {:?}", p)).into_response();
        }
    }

    let out_name = if req.output_name.ends_with(".mal") {
        req.output_name.clone()
    } else {
        req.output_name.clone() + ".mal"
    };

    let output_dir = PathBuf::from(&req.output_dir);
    if let Err(e) = fs::create_dir_all(&output_dir) {
        return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response();
    }

    let mut output = output_dir.join(&out_name);
    if output.exists() {
        let stem = out_name.trim_end_matches(".mal");
        let mut counter = 1;
        while output.exists() {
            output = output_dir.join(format!("{}-{}.mal", stem, counter));
            counter += 1;
        }
    }

    match compress_to_archive(&inputs, &output, req.level) {
        Ok((orig, comp)) => {
            let saved_pct = if orig > 0 {
                (1.0 - comp as f64 / orig as f64) * 100.0
            } else {
                0.0
            };
            Json(CompressResp {
                saved_pct,
                original: orig,
                compressed: comp,
                output_path: output.to_string_lossy().to_string(),
            })
            .into_response()
        }
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

#[derive(Deserialize)]
struct DecompressReq {
    full_paths: Vec<String>,
    output_dir: String,
}

#[derive(Serialize)]
struct DecompressResp {
    files_extracted: usize,
}

async fn handle_decompress(Json(req): Json<DecompressReq>) -> Response {
    let out_dir = PathBuf::from(&req.output_dir);
    let mut total = 0;
    for path_str in &req.full_paths {
        let p = PathBuf::from(path_str);
        match decompress_archive(&p, &out_dir) {
            Ok(n) => total += n,
            Err(e) => return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
        }
    }
    Json(DecompressResp {
        files_extracted: total,
    })
    .into_response()
}

#[derive(Deserialize)]
struct VerifyReq {
    full_paths: Vec<String>,
}

#[derive(Serialize)]
struct VerifyResp {
    file_count: usize,
}

async fn handle_verify(Json(req): Json<VerifyReq>) -> Response {
    let mut total = 0;
    for path_str in &req.full_paths {
        let p = PathBuf::from(path_str);
        match verify_archive(&p) {
            Ok(n) => total += n,
            Err(e) => return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
        }
    }
    Json(VerifyResp { file_count: total }).into_response()
}

#[derive(Deserialize)]
struct DeleteReq {
    full_paths: Vec<String>,
}

async fn handle_delete(Json(req): Json<DeleteReq>) -> Response {
    for path_str in &req.full_paths {
        let p = PathBuf::from(path_str);
        let r = if p.is_dir() {
            fs::remove_dir_all(&p)
        } else {
            fs::remove_file(&p)
        };
        if let Err(e) = r {
            return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response();
        }
    }
    Json(serde_json::json!({"ok": true})).into_response()
}

#[derive(Deserialize)]
struct MkdirReq {
    parent_path: String,
    name: String,
}

async fn handle_mkdir(Json(req): Json<MkdirReq>) -> Response {
    let target = PathBuf::from(&req.parent_path).join(&req.name);
    match fs::create_dir_all(&target) {
        Ok(_) => Json(serde_json::json!({"ok": true})).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

#[derive(Deserialize)]
struct RenameReq {
    old_path: String,
    new_name: String,
}

async fn handle_rename(Json(req): Json<RenameReq>) -> Response {
    let old = PathBuf::from(&req.old_path);
    let new = old.parent().unwrap_or(Path::new("/")).join(&req.new_name);
    match fs::rename(&old, &new) {
        Ok(_) => Json(serde_json::json!({"ok": true})).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

async fn handle_index() -> Html<&'static str> {
    Html(include_str!("ui.html"))
}

pub fn create_router() -> Router {
    Router::new()
        .route("/", get(handle_index))
        .route("/api/list", get(handle_list))
        .route("/api/favpath", get(handle_favpath))
        .route("/api/compress", post(handle_compress))
        .route("/api/decompress", post(handle_decompress))
        .route("/api/verify", post(handle_verify))
        .route("/api/delete", post(handle_delete))
        .route("/api/mkdir", post(handle_mkdir))
        .route("/api/rename", post(handle_rename))
}