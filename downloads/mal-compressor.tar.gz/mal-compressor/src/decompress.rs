use anyhow::{Context, Result};
use crc32fast::Hasher;
use flate2::write::DeflateDecoder;
use std::fs::{self, File};
use std::io::{BufReader, Read, Write};
use std::path::Path;

use crate::archive::{FileEntry, MalHeader, MAGIC};
use crate::utils::deserialize;

pub fn decompress_archive(input: &Path, output_dir: &Path) -> Result<usize> {
    let mut file = BufReader::new(
        File::open(input).context(format!("Impossible d'ouvrir {:?}", input))?,
    );

    let mut hlen = [0u8; 4];
    file.read_exact(&mut hlen)?;
    let mut hbytes = vec![0u8; u32::from_le_bytes(hlen) as usize];
    file.read_exact(&mut hbytes)?;
    let header: MalHeader = deserialize(&hbytes)?;

    if &header.magic != MAGIC {
        anyhow::bail!("Fichier invalide (magic number incorrect)");
    }

    let mut compressed_blocks = Vec::new();
    for _ in 0..header.file_count {
        let mut slen = [0u8; 4];
        file.read_exact(&mut slen)?;
        let mut block = vec![0u8; u32::from_le_bytes(slen) as usize];
        file.read_exact(&mut block)?;
        compressed_blocks.push(block);
    }

    let mut ilen = [0u8; 4];
    file.read_exact(&mut ilen)?;
    let mut ibytes = vec![0u8; u32::from_le_bytes(ilen) as usize];
    file.read_exact(&mut ibytes)?;
    let entries: Vec<FileEntry> = deserialize(&ibytes)?;

    fs::create_dir_all(output_dir)?;

    for (i, entry) in entries.iter().enumerate() {
        let clean = entry.path.replace('\\', "/");
        let parts: Vec<&str> = clean
            .split('/')
            .filter(|p| !p.is_empty() && *p != "..")
            .collect();
        let dest = parts
            .iter()
            .fold(output_dir.to_path_buf(), |acc, p| acc.join(p));

        if let Some(parent) = dest.parent() {
            fs::create_dir_all(parent)?;
        }

        let mut decoder = DeflateDecoder::new(Vec::new());
        decoder.write_all(&compressed_blocks[i])?;
        let data = decoder.finish()?;

        let mut h = Hasher::new();
        h.update(&data);
        if h.finalize() != entry.crc32 {
            anyhow::bail!("CRC32 invalide pour {}", entry.path);
        }

        fs::write(&dest, &data)?;
    }

    Ok(entries.len())
}