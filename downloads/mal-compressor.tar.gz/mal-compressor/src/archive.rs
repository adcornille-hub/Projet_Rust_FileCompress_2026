use serde::{Deserialize, Serialize};

pub const MAGIC: &[u8; 4] = b"MAL\0";
pub const VERSION: u8 = 1;

#[derive(Debug, Serialize, Deserialize)]
pub struct MalHeader {
    pub magic: [u8; 4],
    pub version: u8,
    pub compression_level: u8,
    pub file_count: u32,
    pub total_original_size: u64,
    pub total_compressed_size: u64,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct FileEntry {
    pub path: String,
    pub original_size: u64,
    pub compressed_size: u64,
    pub crc32: u32,
    pub offset: u64,
}