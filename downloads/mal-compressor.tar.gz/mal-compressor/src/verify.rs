use anyhow::Result;
use crc32fast::Hasher;
use flate2::write::DeflateDecoder;
use std::fs::File;
use std::io::{BufReader, Read, Write};
use std::path::Path;

use crate::archive::{FileEntry, MalHeader, MAGIC};
use crate::utils::deserialize;

pub fn verify_archive(input: &Path) -> Result<usize> {
    let mut file = BufReader::new(File::open(input)?);

    let mut hlen = [0u8; 4];
    file.read_exact(&mut hlen)?;
    let mut hbytes = vec![0u8; u32::from_le_bytes(hlen) as usize];
    file.read_exact(&mut hbytes)?;
    let header: MalHeader = deserialize(&hbytes)?;

    if &header.magic != MAGIC {
        anyhow::bail!("Magic number invalide");
    }

    let mut blocks = Vec::new();
    for _ in 0..header.file_count {
        let mut slen = [0u8; 4];
        file.read_exact(&mut slen)?;
        let mut block = vec![0u8; u32::from_le_bytes(slen) as usize];
        file.read_exact(&mut block)?;
        blocks.push(block);
    }

    let mut ilen = [0u8; 4];
    file.read_exact(&mut ilen)?;
    let mut ibytes = vec![0u8; u32::from_le_bytes(ilen) as usize];
    file.read_exact(&mut ibytes)?;
    let entries: Vec<FileEntry> = deserialize(&ibytes)?;

    let mut errors = Vec::new();
    for (i, entry) in entries.iter().enumerate() {
        let mut decoder = DeflateDecoder::new(Vec::new());
        if decoder.write_all(&blocks[i]).is_err() {
            errors.push(format!("{}: erreur decomp", entry.path));
            continue;
        }
        let data = match decoder.finish() {
            Ok(d) => d,
            Err(_) => {
                errors.push(format!("{}: decomp echouee", entry.path));
                continue;
            }
        };
        if data.len() as u64 != entry.original_size {
            errors.push(format!("{}: taille incorrecte", entry.path));
        }
        let mut h = Hasher::new();
        h.update(&data);
        if h.finalize() != entry.crc32 {
            errors.push(format!("{}: CRC32 invalide", entry.path));
        }
    }

    if !errors.is_empty() {
        anyhow::bail!("Erreurs: {}", errors.join("; "));
    }
    Ok(entries.len())
}