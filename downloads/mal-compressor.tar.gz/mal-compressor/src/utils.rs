use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io::{BufReader, Read};
use std::path::{Path, PathBuf};

use crate::archive::{MalHeader, MAGIC};

pub fn serialize<T: Serialize>(v: &T) -> Result<Vec<u8>> {
    Ok(serde_json::to_vec(v)?)
}

pub fn deserialize<T: for<'de> Deserialize<'de>>(b: &[u8]) -> Result<T> {
    Ok(serde_json::from_slice(b)?)
}

pub fn resolve(path: &str) -> PathBuf {
    let p = PathBuf::from(path);
    if p.is_absolute() {
        p
    } else {
        home_dir_path().join(p)
    }
}

pub fn home_dir_path() -> PathBuf {
    std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("/"))
}

pub fn home_dir_str() -> String {
    home_dir_path().to_string_lossy().to_string()
}

pub fn dirs_path(name: &str) -> String {
    let candidates: Vec<&str> = match name {
        "Desktop" => vec!["Desktop", "Bureau"],
        "Documents" => vec!["Documents"],
        "Downloads" => vec!["Downloads", "Téléchargements", "Telechargements"],
        _ => vec![name],
    };
    let home = home_dir_path();
    for candidate in candidates {
        let p = home.join(candidate);
        if p.exists() {
            return p.to_string_lossy().to_string();
        }
    }
    home.to_string_lossy().to_string()
}

#[derive(Serialize)]
pub struct DiskInfo {
    pub total: u64,
    pub used: u64,
    pub free: u64,
    pub label: String,
}

pub fn get_disk_info(path: &Path) -> Option<DiskInfo> {
    #[cfg(unix)]
    {
        use std::mem::MaybeUninit;
        let path_cstr = std::ffi::CString::new(path.to_str()?).ok()?;
        let mut stat: MaybeUninit<libc::statvfs> = MaybeUninit::uninit();
        unsafe {
            if libc::statvfs(path_cstr.as_ptr(), stat.as_mut_ptr()) != 0 {
                return None;
            }
            let s = stat.assume_init();
            let block = s.f_frsize as u64;
            let total = s.f_blocks * block;
            let free = s.f_bavail * block;
            let used = total.saturating_sub(free);
            Some(DiskInfo {
                total,
                used,
                free,
                label: path.to_str().unwrap_or("/").to_string(),
            })
        }
    }
    #[cfg(not(unix))]
    {
        let _ = path;
        None
    }
}

pub fn time_from_secs(secs: u64) -> (u32, u32, u32, u32, u32) {
    let mins = secs / 60;
    let hrs = mins / 60;
    let days = hrs / 24;
    let h = (hrs % 24) as u32;
    let m = (mins % 60) as u32;
    let jdn = days as i64 + 2440588;
    let l = jdn + 68569;
    let n = 4 * l / 146097;
    let l = l - (146097 * n + 3) / 4;
    let i = 4000 * (l + 1) / 1461001;
    let l = l - 1461 * i / 4 + 31;
    let j = 80 * l / 2447;
    let d = (l - 2447 * j / 80) as u32;
    let l = j / 11;
    let mo = (j + 2 - 12 * l) as u32;
    let y = (100 * (n - 49) + i + l) as u32;
    (y, mo, d, h, m)
}

#[derive(Serialize)]
pub struct MalInfo {
    pub file_count: u32,
    pub original_size: u64,
    pub compressed_size: u64,
    pub ratio: f64,
}

pub fn read_mal_info(path: &Path) -> Option<MalInfo> {
    let mut file = BufReader::new(File::open(path).ok()?);
    let mut hlen = [0u8; 4];
    file.read_exact(&mut hlen).ok()?;
    let mut hbytes = vec![0u8; u32::from_le_bytes(hlen) as usize];
    file.read_exact(&mut hbytes).ok()?;
    let header: MalHeader = deserialize(&hbytes).ok()?;
    if &header.magic != MAGIC {
        return None;
    }
    let ratio = if header.total_original_size > 0 {
        header.total_compressed_size as f64 / header.total_original_size as f64
    } else {
        1.0
    };
    Some(MalInfo {
        file_count: header.file_count,
        original_size: header.total_original_size,
        compressed_size: header.total_compressed_size,
        ratio,
    })
}