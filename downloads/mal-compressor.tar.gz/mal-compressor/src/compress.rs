use anyhow::{Context, Result};
use crc32fast::Hasher;
use flate2::write::DeflateEncoder;
use flate2::Compression;
use std::fs::{self, File};
use std::io::{BufWriter, Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use walkdir::WalkDir;

use crate::archive::{FileEntry, MalHeader, MAGIC, VERSION};
use crate::utils::serialize;

// On fixe une taille constante pour l'en-tête pour éviter de 
// décaler les données lorsqu'on le met à jour à la fin du processus.
const HEADER_ALLOC_SIZE: usize = 512;

pub fn collect_files(root: &Path) -> Result<Vec<PathBuf>> {
    let mut files = Vec::new();
    if root.is_file() {
        files.push(root.to_path_buf());
    } else if root.is_dir() {
        for entry in WalkDir::new(root).follow_links(false) {
            let e = entry?;
            if e.file_type().is_file() {
                files.push(e.path().to_path_buf());
            }
        }
    }
    Ok(files)
}

pub fn compress_to_archive(inputs: &[PathBuf], output: &Path, level: u8) -> Result<(u64, u64)> {
    let mut all_files = Vec::new();
    for input in inputs {
        all_files.extend(collect_files(input)?);
    }

    if all_files.is_empty() {
        anyhow::bail!("Aucun fichier a compresser");
    }

    let total_original: u64 = all_files
        .iter()
        .filter_map(|f| fs::metadata(f).ok())
        .map(|m| m.len())
        .sum();

    let compression = match level {
        0 => Compression::none(),
        1 => Compression::fast(),
        9 => Compression::best(),
        n => Compression::new(n as u32),
    };

    let base_dir = if inputs.len() == 1 && inputs[0].is_dir() {
        inputs[0].parent().unwrap_or(&inputs[0]).to_path_buf()
    } else {
        inputs[0].parent().unwrap_or(Path::new("/")).to_path_buf()
    };

    let mut out = BufWriter::new(
        File::create(output).context(format!("Impossible de creer {:?}", output))?,
    );
    let mut file_entries: Vec<FileEntry> = Vec::new();
    let mut current_offset = 0u64;
    let mut compressed_blocks: Vec<Vec<u8>> = Vec::new();

    let temp_header = MalHeader {
        magic: *MAGIC,
        version: VERSION,
        compression_level: level,
        file_count: all_files.len() as u32,
        total_original_size: total_original,
        total_compressed_size: 0,
    };
    
    let mut hbytes = serialize(&temp_header)?;
    if hbytes.len() > HEADER_ALLOC_SIZE {
        anyhow::bail!("L'en-tête JSON est trop grand pour l'espace alloué.");
    }
    // FIX : On complète avec des espaces (b' ') jusqu'à 512 octets
    hbytes.resize(HEADER_ALLOC_SIZE, b' ');

    out.write_all(&(hbytes.len() as u32).to_le_bytes())?;
    out.write_all(&hbytes)?;
    current_offset += 4 + hbytes.len() as u64;

    let mut total_compressed = 0u64;

    for file_path in &all_files {
        let mut fh = File::open(file_path).context(format!("Impossible d'ouvrir {:?}", file_path))?;
        let mut data = Vec::new();
        fh.read_to_end(&mut data)?;

        let original_size = data.len() as u64;
        let mut hasher = Hasher::new();
        hasher.update(&data);
        let crc32 = hasher.finalize();

        let mut encoder = DeflateEncoder::new(Vec::new(), compression);
        encoder.write_all(&data)?;
        let compressed = encoder.finish()?;
        let compressed_size = compressed.len() as u64;

        let rel_path = file_path
            .strip_prefix(&base_dir)
            .unwrap_or(file_path)
            .to_string_lossy()
            .to_string();

        file_entries.push(FileEntry {
            path: rel_path,
            original_size,
            compressed_size,
            crc32,
            offset: current_offset,
        });
        current_offset += 4 + compressed_size;
        total_compressed += compressed_size;
        compressed_blocks.push(compressed);
    }

    for block in &compressed_blocks {
        out.write_all(&(block.len() as u32).to_le_bytes())?;
        out.write_all(block)?;
    }

    let idx = serialize(&file_entries)?;
    out.write_all(&(idx.len() as u32).to_le_bytes())?;
    out.write_all(&idx)?;
    out.flush()?;
    drop(out);

    let final_header = MalHeader {
        total_compressed_size: total_compressed,
        ..temp_header
    };
    
    let mut fhbytes = serialize(&final_header)?;
    // FIX : On applique exactement le même padding au header final
    fhbytes.resize(HEADER_ALLOC_SIZE, b' ');

    let mut fh = File::options().write(true).open(output)?;
    fh.seek(SeekFrom::Start(0))?;
    fh.write_all(&(fhbytes.len() as u32).to_le_bytes())?;
    fh.write_all(&fhbytes)?;
    fh.flush()?;

    Ok((total_original, total_compressed))
}