mod api;
mod archive;
mod compress;
mod decompress;
mod utils;
mod verify;

use anyhow::{Context, Result};

#[tokio::main]
async fn main() -> Result<()> {
    let port = find_free_port(7890);
    let addr = format!("127.0.0.1:{}", port);

    let app = api::create_router();
    let url = format!("http://{}", addr);

    println!("MAL Explorer -- demarrage");
    println!("Serveur : {}", url);
    println!("Ctrl+C  : quitter");

    let url_clone = url.clone();
    tokio::spawn(async move {
        tokio::time::sleep(tokio::time::Duration::from_millis(400)).await;
        if let Err(e) = open::that(&url_clone) {
            eprintln!(
                "Impossible d'ouvrir le navigateur: {}. \
                 Ouvrez {} manuellement.",
                e, url_clone
            );
        }
    });

    let listener = tokio::net::TcpListener::bind(&addr)
        .await
        .context(format!("Impossible de demarrer sur {}", addr))?;

    axum::serve(listener, app).await?;
    Ok(())
}

fn find_free_port(start: u16) -> u16 {
    for port in start..=65535 {
        if std::net::TcpListener::bind(format!("127.0.0.1:{}", port)).is_ok() {
            return port;
        }
    }
    start
}