@echo off
chcp 65001 >nul
echo ╔══════════════════════════════════════╗
echo ║    MAL Explorer — Build Script        ║
echo ╚══════════════════════════════════════╝
echo.

where cargo >nul 2>&1
if %errorlevel% neq 0 (
    echo Rust/Cargo non trouvé.
    echo Installez Rust : https://rustup.rs
    pause
    exit /b 1
)

echo Compilation en mode release...
echo Cela peut prendre 1-2 minutes la premiere fois.
echo.

cargo build --release

if %errorlevel% neq 0 (
    echo Erreur de compilation.
    pause
    exit /b 1
)

echo.
echo Build reussi !
echo.
echo MAL Explorer est pret : target\release\mal.exe
echo.
set /p launch="Lancer maintenant ? [O/n] "
if /i "%launch%"=="n" goto :end
start "" "target\release\mal.exe"
:end
pause
