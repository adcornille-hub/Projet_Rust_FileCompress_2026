# MAL Explorer

Explorateur de fichiers avec compression/décompression `.mal` intégrée.  
**Un seul binaire à lancer** — l'interface s'ouvre automatiquement dans votre navigateur.

---

## Installation & Lancement

### Prérequis
- [Rust](https://rustup.rs) (installateur universel, 2 min)

### Linux / macOS
```bash
chmod +x build.sh
./build.sh
```
Puis, pour les prochains lancements :
```bash
./target/release/mal
```

### Windows
Double-cliquer sur `build.bat`, puis lancer `target\release\mal.exe`.

---

## Utilisation

Au lancement, le programme :
1. Démarre un serveur local sur `http://127.0.0.1:7890`
2. Ouvre automatiquement votre navigateur sur cette adresse
3. Affiche votre répertoire personnel comme point de départ

**Fermez la fenêtre du terminal** pour arrêter le serveur.

---

## Interface

| Élément | Description |
|---------|-------------|
| Badge vert `.mal` | Archive MAL compressée |
| Badge gris `ext` | Fichier non compressé |
| Badge jaune `dossier` | Répertoire |
| Ratio | Taille compressée / originale (plus bas = mieux) |

**Codes couleur du ratio :**
- Vert → < 50% (excellente compression)
- Orange → 50-75% (compression correcte)
- Gris → > 75% (peu compressible, ex: JPEG)

---

## Fonctionnalités

### Compression
1. Sélectionner des fichiers (Ctrl+clic pour multi-sélection)
2. Clic sur **Compresser (.mal)**
3. Choisir le niveau (0=aucun, 6=défaut, 9=maximum)
4. Nommer l'archive de sortie
5. Lancer

### Décompression
1. Sélectionner une ou plusieurs archives `.mal`
2. Clic sur **Décompresser**
3. Choisir le dossier de destination
4. Extraire

### Vérification d'intégrité
Sélectionner une archive `.mal` → **Vérifier** → vérifie le magic number + CRC32 de chaque fichier.

### Raccourcis clavier
| Touche | Action |
|--------|--------|
| `F5` | Actualiser |
| `Ctrl+A` | Tout sélectionner |
| `Backspace` | Dossier parent |
| `Delete` | Supprimer la sélection |
| `Escape` | Fermer la modale |

---

## Format .mal

```
[4 octets] Longueur du header
[N octets] Header JSON (magic, version, nb fichiers, tailles)
[répété pour chaque fichier]
  [4 octets] Longueur du bloc compressé
  [N octets] Données Deflate
[4 octets] Longueur de l'index
[N octets] Index JSON (chemins, tailles, CRC32, offsets)
```

- Compression : **Deflate** (flate2)
- Intégrité : **CRC32** par fichier
- Sérialisation : **JSON** (lisible et debuggable)

---

## Structure du projet

```
mal-compressor/
├── Cargo.toml          # Dépendances Rust
├── build.sh            # Script build Linux/macOS
├── build.bat           # Script build Windows
├── README.md
└── src/
    ├── main.rs # point d'entrée + serveur
    ├── compress.rs # logique compression
    ├── decompress.rs # logique décompression
    ├── verify.rs # vérification intégrité
    ├── archive.rs # structures partagées (MalHeader, FileEntry...)
    ├── api.rs # handlers HTTP (axum)
    ├── ui.html # interface web.
    └── utils.rs # utilitaires (format taille, chemins, disque...)


si tu as des question sur le travail à venir, pose les moi avant de me donner un résultat et attend qui j'y réponde.
```

---

## Sécurité

- Le serveur écoute **uniquement sur 127.0.0.1** (pas accessible depuis le réseau)
- Les chemins sont nettoyés (pas de traversée `../`)
- Toutes les opérations restent dans les limites du système de fichiers local
