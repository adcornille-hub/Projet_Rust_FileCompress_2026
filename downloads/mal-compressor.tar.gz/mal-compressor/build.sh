#!/usr/bin/env bash
set -e

echo "╔══════════════════════════════════════╗"
echo "║    MAL Explorer — Build Script        ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Vérifier Rust
if ! command -v cargo &> /dev/null; then
    echo "Rust/Cargo non trouvé."
    echo "Installez Rust : https://rustup.rs"
    exit 1
fi

echo "Compilation en mode release (optimisé)..."
echo "Cela peut prendre 1-2 minutes la première fois."
echo ""

cargo build --release

BINARY="./target/release/mal"
echo ""
echo "Build réussi !"
echo ""
echo "Pour lancer MAL Explorer :"
echo "  $BINARY"
echo ""

# Proposer de lancer directement
read -p "Lancer MAL Explorer maintenant ? [O/n] " choice
case "$choice" in
    n|N ) echo "Ok, lancez-le plus tard avec : $BINARY" ;;
    *   ) exec "$BINARY" ;;
esac
